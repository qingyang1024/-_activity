### Guns集成Activiti工作流版本
Guns原版详见: https://gitee.com/stylefeng/guns

## 启动方式
1.下载代码

2.修改数据库账户密码配置

3.导入guns.sql

4.运行GunsApplication

## 演示地址
[演示地址](http://tpot.com.cn:8083)

## 集成流程编辑器
![集成流程编辑器](https://images.gitee.com/uploads/images/2019/1108/161300_5ccb527b_1564001.png "屏幕截图.png")

## 模型管理
![模型管理](https://images.gitee.com/uploads/images/2019/1108/161349_4dfd5840_1564001.png "屏幕截图.png")

## 部署管理
![部署管理](https://images.gitee.com/uploads/images/2019/1108/161415_0a3ba0fa_1564001.png "屏幕截图.png")

## 流程监控
![流程监控](https://images.gitee.com/uploads/images/2019/1108/162543_853eb2db_1564001.png "屏幕截图.png")

## 待办任务
![待办任务](https://images.gitee.com/uploads/images/2019/1108/162642_5a2169c7_1564001.png "屏幕截图.png")

## 已办任务
![已办任务](https://images.gitee.com/uploads/images/2019/1108/162718_9f8ae497_1564001.png "屏幕截图.png")

## 查看流程图
![查看流程图](https://images.gitee.com/uploads/images/2019/1108/162759_0ab54233_1564001.png "屏幕截图.png")

## 查看审批记录
![查看审批记录](https://images.gitee.com/uploads/images/2019/1108/162908_c444b20f_1564001.png "屏幕截图.png")

## 转办/委托
![转办/委托](https://images.gitee.com/uploads/images/2019/1108/162950_a8e50188_1564001.png "屏幕截图.png")

## 请假Demo
![请假Demo](https://images.gitee.com/uploads/images/2019/1108/163048_5e24cf58_1564001.png "屏幕截图.png")