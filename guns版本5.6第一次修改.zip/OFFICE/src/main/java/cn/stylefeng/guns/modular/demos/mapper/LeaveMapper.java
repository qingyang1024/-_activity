package cn.stylefeng.guns.modular.demos.mapper;

import cn.stylefeng.guns.modular.demos.entity.Leave;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 请假Mapper接口
 *
 * @Author xuyuxiang
 * @Date 2019/10/25 16:15
 **/
public interface LeaveMapper extends BaseMapper<Leave> {

}
